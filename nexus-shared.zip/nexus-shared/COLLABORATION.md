# Git and integration workflow
1. Team lead commits shared docs to main. All developers pull the same revision.
2. Each developer creates their own feature branch (or switches to it if already created).
3. Before work, check git status. Commit only your own files after testing.
4. Push your branch and open a pull request. Team lead reviews contract compatibility and tests before merging.
5. Synchronize main at agreed checkpoints; resolve conflicts with the relevant owner. Never overwrite another teammate's changes.
6. Contract changes require agreement from AI, backend and frontend owners; update docs first, then implementations.

## Branches
feat/ml-engine, feat/frontend, feat/backend, docs/research.

## Checkpoints
First hour: contract agreement and environment verification.
First integration: mock UI and backend health check, then real model results on synthetic data.
MVP target: hour 8 (estimate, not guarantee).
Final: freeze features, test, record actual metrics, rehearse and submit.

## Status handoff
Each owner reports: completed / tested / blocked / next / contract changes requested.
