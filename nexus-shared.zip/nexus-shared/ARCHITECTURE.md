# Nexus Sentinel — shared architecture
Version: 1.0 (proposed; team lead approves changes)

## Scope
Defensive ransomware early-warning demonstration using synthetic tabular observations only. No actual malware, file modification, process termination or network changes. Containment is a simulated endpoint state. Do not claim production protection.

## Stack and ownership
- ml_engine/ and datasets/: AI lead; Python, scikit-learn, pandas, joblib.
- frontend/: RTX 4050 teammate; React, Vite, Tailwind, Recharts, Lucide.
- backend/ and simulator/: HP teammate; FastAPI, SQLite, synthetic records only.
- docs/: fourth member; requirements, QA, research, pitch.
- Root documentation and shared contracts: team lead approval.

## Flow
Synthetic observations → classifier → risk assessment → backend → dashboard and simulated containment alert.

## Acceptance
Demonstrate normal activity, legitimate backup and suspicious synthetic observations. Report measured precision, recall, false-positive rate and simulated detection latency. Explain limitations. Use held-out scenarios; never fabricate metrics.
