# Mandatory agent instructions
Read ARCHITECTURE.md, API_CONTRACT.md, COLLABORATION.md and your assigned role file before editing. These documents override guesses about the project. Ask the human owner about conflicts.

- Work only in assigned folders. Do not edit other components, root contracts or shared dependencies without approval.
- Inspect existing files first; preserve working code. Make one scoped change at a time.
- Do not redesign interfaces, rename fields, change ports or add dependencies without approval.
- Use synthetic records only. No real malware, destructive operations or real isolation.
- Never fabricate test results or silently substitute mock results for actual predictions. Label mock data clearly.
- Run relevant tests and report files changed, commands run, results, blockers and next step.
- Never commit secrets, virtual environments, node_modules or unreviewed large artifacts.
- Never force-push, reset another person's work or merge without human approval.
