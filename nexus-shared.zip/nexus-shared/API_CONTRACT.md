# Shared interface — v1
Team must approve before implementation. All examples are illustrative, not measured results.

## HTTP conventions
Local backend: http://localhost:8000. Frontend: Vite default port 5173. JSON, UTC ISO-8601 timestamps, snake_case keys. Configure local CORS explicitly. No secrets in source.

## Endpoints
- GET /api/v1/health — {"status":"ok"}
- GET /api/v1/endpoints — {"items":[{"endpoint_id":"demo-01","status":"monitoring"}]}
- GET /api/v1/assessments — {"items":[]} (assessment records below)
- GET /api/v1/incidents — {"items":[]} (incident records below)
- POST /api/v1/demo/start — {"scenario":"normal"} (normal, backup, suspicious; synthetic only)
- POST /api/v1/demo/reset — reset demo state only.

## Assessment record
```json
{"assessment_id":"a-001","endpoint_id":"demo-01","timestamp":"2026-01-01T00:00:00Z","risk_score":72,"label":"suspicious","indicators":["unusual activity"],"simulated":true}
```
Risk score is a model-derived score from 0 to 100, not a calibrated probability unless validated. Labels: normal, suspicious, unknown. Unknown means no valid assessment; do not fabricate a score (use null).

## Incident record
```json
{"incident_id":"i-001","endpoint_id":"demo-01","assessment_id":"a-001","status":"simulated_isolated","checklist":["Notify security team","Review incident evidence"],"simulated":true}
```
Endpoint status: monitoring, simulated_isolated. Frontend polls read endpoints initially; no WebSocket requirement. Errors use HTTP status and FastAPI detail field.

## ML boundary
AI lead and backend owner agree on a versioned synthetic feature schema and prediction function before implementation. Keep feature definitions in a shared reviewed document. Return the assessment fields above; backend supplies IDs and timestamps. Load only trusted locally produced model artifacts. No live system access.
